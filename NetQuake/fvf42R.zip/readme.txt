Future vs. Fantasy Documentation  v. 4.0  
Quake Conversion

Freeform Interactive
http://www.freeformint.com

FvF Web Page
http://fvf.warzone.com
    
Future vs. Fantasy is copyrighted by Freeform Interactive.

QUAKE� � 1996 is a registered trademark of Id Software, Inc.

Neither FvF nor Freeform Interactive are in any way affiliated with id 
Software, Inc.  Id Software will not provide technical or other support
for FvF.


---------------------------------------------------------------
---------------------------------------------------------------
[Readme Documentation]

Please read FVF4.TXT for primary FvF Manual.
Please read SERVER.TXT for information on RUNNING AN FvF SERVER
Please read LEVEL.TXT for information on FvF Levels
Please read ORDER.TXT for registering FvF (If you have not already)
--------------------------------------------------------------
---------------------------------------------------------------

	Future vs. Fantasy Quake (hereby referred to as "FvF" or "the
        software") is provided AS IS.  Neither FreeForm Interactive (FI),
        Hap (hap@ucsd.edu), kenn (kenn@autobahn.org), Raison
        (raison@concentric.net), nor any individuals either associated or not
        associated with FI, including, but not limited to any individual
        mentioned by the above or this documentation file, is responsible for
        any damage, or financial, physical, emotional, spiritual, economic,
        temporal, or spatial loss that may result from running or even simply
        possessing the software. FreeForm Interactive also claims the right
        to modify this document without prior notification, but will most
        likely refrain from including clauses that bequeath unto FI any
        property or family members of individuals using the software and
        thus abiding by this disclaimer/ad hoc license agreement.


---------------------------------------------------------------
---------------------------------------------------------------
[Major Features]

         382 New Textures 
         85 New Sounds
         82 Original Models*          
         80 Different Weapons
         16 Custom Skins
         14 Unique Character Classes
         13 Original Levels**
         10 New Monsters**
         New Menus and Fonts
         Full Single Player and Multiplayer Support
         Quakeworld Compatible
         Professional Documentation
         No Impulses to Bind
         No Aliases to Learn
         Direct Support for Single-player Mode
         Remote Administration (100% Flexible) 
         Customizable Toggles without QuakeC Programming 
         Quest Mode: Cooperative/RPG Network
         Purge Mode: Goal-Oriented, 2 Teams Deathmatch

         *  Unregistered FvF has 60 new models.  
         ** Registered Version Only 




---------------------------------------------------------------
---------------------------------------------------------------
[Minimum Recommended Requirements]

        The following lists the minimum requirements recommended
        to play FvF (as a client).  
        
	Registered Quake
        Pentium 100
        16 Megs of RAM
        
        WinQuake 1.0 or later is highly recommended but not
        necessary.  WinQuake is avalible at: ftp.idsoftware.com.


-----
[Quick Start]

1. Decompress FvF into a SUBDIRECTORY under QUAKE.
		
	For example:
	If Quake is stored in C:\QUAKE, then decompress FvF into
        C:\QUAKE\FVF.

	If Quake is in D:\GAMES\QUAKE, then decompress into
        D:\GAMES\QUAKE\FVF.

2. Run Quake with the command QUAKE.EXE -GAME FVF.

        It is recommended you get WinQuake 1.0. If you have WinQuake
        use the following command:
        
        WINQUAKE -GAME FVF -WINMEM 16 -WINLOCK

3. Run Quake as you normally would.

        To change character classes, push 9 or 0 on your keyboard.  
  